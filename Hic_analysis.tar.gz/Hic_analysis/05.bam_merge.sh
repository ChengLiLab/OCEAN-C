samtools merge /lustre/user/liclab/jialm/faire-seq/hicdata/ourdatahiC_hela/hela_hic/fastq/BAM/hela-hic-1_DO15122852_HJ535CCXX.trim.merge.bam  /lustre/user/liclab/jialm/faire-seq/hicdata/ourdatahiC_hela/hela_hic/fastq/BAM/*.trim.bam &

samtools merge /lustre/user/liclab/jialm/faire-seq/faireCdata/ourdatafaireC_hela/faire_c_hela_20151231/fastq/hela_faire_c_1/BAM/hela-faire-c-1_DO15122852_HJ535CCXX.trim.merge.bam  /lustre/user/liclab/jialm/faire-seq/faireCdata/ourdatafaireC_hela/faire_c_hela_20151231/fastq/hela_faire_c_1/BAM/*.bam &

samtools merge /lustre/user/liclab/jialm/faire-seq/faireCdata/ourdatafaireC_hela/faire_c_hela_20151231/fastq/hela_faire_c_2/BAM/hela-faire-c-2_DO15122852_HJ535CCXX.trim.merge.bam  /lustre/user/liclab/jialm/faire-seq/faireCdata/ourdatafaireC_hela/faire_c_hela_20151231/fastq/hela_faire_c_2/BAM/*.bam &
